return {
  mod = require('configuration.keys.mod'),
  global = require('configuration.keys.global')
}
